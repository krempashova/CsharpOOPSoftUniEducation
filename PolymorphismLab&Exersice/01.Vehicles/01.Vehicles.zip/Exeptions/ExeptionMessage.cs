﻿namespace Vehicles.Exeptions
{
    public static class ExeptionMessage
    {

        public const string Message =
            "{0} needs refueling";
    }
}
