﻿namespace FoodShortage.Models.Interfaces
{
    public interface IIndentifable
    {

        string Id { get; }
    }
}
