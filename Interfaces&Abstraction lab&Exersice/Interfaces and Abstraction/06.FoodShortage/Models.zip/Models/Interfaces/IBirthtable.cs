﻿namespace FoodShortage.Models.Interfaces
{
    public interface IBirthtable
    {

        string Birthdate { get; }
    }
}
