﻿namespace FoodShortage.Models.Interfaces
{
    public interface INamemable
    {
        string Name { get; }
    }
}
