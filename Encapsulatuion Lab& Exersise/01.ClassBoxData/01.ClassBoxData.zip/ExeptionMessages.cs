﻿namespace _01.ClassBoxData
{
    public static class ExeptionMessages
    {

        public const string BoxofParametarsCannotbeZeroOrNegative = 
            "{0} cannot be zero or negative.";
    }
}
