﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Gyms
{
    public class BoxingGym : Gym
    {
        public BoxingGym(string name) 
            
            // i ma not shure if is included or no
            : base(name,15)
        {
        }
    }
}
