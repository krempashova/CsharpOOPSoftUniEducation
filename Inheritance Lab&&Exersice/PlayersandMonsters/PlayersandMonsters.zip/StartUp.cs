﻿using PlayersandMonsters;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            DarkWizard darkWizard = new DarkWizard("gOSHO", 7);
            Console.WriteLine(darkWizard.ToString());
        }
    }
}